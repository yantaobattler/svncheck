rq=0904                                                                                         
        cd                                                                                                    
        tar cvf TIPS_LOG_$rq.tar   $HOME/log/TIPS/*D$rq*.log  $HOME/log/TTS/*D$rq*.log  $HOME/log/UPF/*D$rq*.log  $HOME/log/CTK/*D$rq*.log  $HOME/log/PDS/*D$rq*.log  $HOME/log/DEFAULT/*D$rq*.log $HOME/log/_DEBUG_/*D$rq*.log  $HOME/log/bic/*$rq*D$rq*.log  $HOME/log/TJNSPL/*D$rq*.log  $HOME/log/basp/*D$rq*.log $HOME/log/DL/*D$rq*.log   $HOME/log/ZFB/*D$rq*.log  $HOME/log/gjjwt/*D$rq*.log $HOME/log/ISTS/*D$rq*.log $HOME/log/WQCZ/*D$rq*.log $HOME/log/bil/*D$rq*.log  $HOME/log/CLS/*D$rq*.log  $HOME/log/GJJ/*D$rq*.log  $HOME/log/FDC/*D$rq*.log  $HOME/log/aps/*D$rq*.log  $HOME/tmp/tipscoredz/*2016$rq*  $HOME/tmp/ttsdz/*2016$rq* $HOME/tmp/file/*2016$rq*  $HOME/tmp/pds/*2016$rq*   $HOME/tmp/dlfile/*2016$rq*  $HOME/tmp/zfbfile/*2016$rq*  $HOME/tmp/batch_transfer/*2016$rq* $HOME/tmp/gjjfile/*2016$rq*   $HOME/tmp/istsfile/*2016$rq* $HOME/tmp/fdcfile/*2016$rq*.data $HOME/tmp/fdcfile/*2016$rq*.TXT  $HOME/tmp/fdcfile/FDC/*2016$rq* $HOME/tmp/aps/*2016$rq*   $HOME/tmp/bildz/*2016$rq* $HOME/tmp/ctkdz/*2016$rq* $HOME/tmp/bil/*2016$rq*        
        compress TIPS_LOG_$rq.tar                                                                               
        mv TIPS_LOG_$rq.tar.Z  $HOME/hisbackup/his_2016                                                      
        rm -f $HOME/log/*.log
        rm -f $HOME/log/TIPS/*D$rq*.log
        rm -f $HOME/log/TTS/*D$rq*.log
        rm -f $HOME/log/UPF/*D$rq*.log
        rm -f $HOME/log/CTK/*D$rq*.log
        rm -f $HOME/log/PDS/*D$rq*.log
        rm -f $HOME/log/DEFAULT/*D$rq*.log
        rm -f $HOME/log/_DEBUG_/*D$rq*.log
        rm -f $HOME/log/bic/*$rq*D$rq*.log
        rm -f $HOME/log/TJNSPL/*D$rq*.log
        rm -f $HOME/log/basp/*D$rq*.log
        rm -f $HOME/log/DL/*D$rq*.log
        rm -f $HOME/log/ZFB/*D$rq*.log
        rm -f $HOME/log/gjjwt/*D$rq*.log
        rm -f $HOME/log/ISTS/*D$rq*.log
        rm -f $HOME/log/WQCZ/*D$rq*.log
        rm -f $HOME/log/bil/*D$rq*.log
        rm -f $HOME/log/CLS/*D$rq*.log
        rm -f $HOME/log/GJJ/*D$rq*.log
        rm -f $HOME/log/FDC/*D$rq*.log
        rm -f $HOME/log/aps/*D$rq*.log 
        rm -f $HOME/tmp/tipscoredz/*2016$rq*
        rm -f $HOME/tmp/ttsdz/*2016$rq*
        rm -f $HOME/tmp/file/*2016$rq*
        rm -f $HOME/tmp/pds/*2016$rq*
        rm -f $HOME/tmp/dlfile/*2016$rq*
        rm -f $HOME/tmp/zfbfile/*2016$rq*
        rm -f $HOME/tmp/batch_transfer/*2016$rq*
        rm -f $HOME/tmp/gjjfile/*2016$rq*
        rm -f  $HOME/tmp/istsfile/*2016$rq*
        rm -f $HOME/tmp/fdcfile/*2016$rq*.data
        rm -f $HOME/tmp/fdcfile/*2016$rq*.TXT
        rm -f $HOME/tmp/fdcfile/FDC/*2016$rq*
        rm -f $HOME/tmp/aps/*2016$rq*
        rm -f $HOME/tmp/bildz/*2016$rq*
        rm -f $HOME/tmp/ctkdz/*2016$rq*
        rm -f $HOME/tmp/bil/*2016$rq*




